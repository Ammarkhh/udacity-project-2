# secend udacity project
# diagram.jpeg contain the diagram discriping the needed resources and network for the project

website url: http://proje-webap-4b0db4uoi044-424264316.us-east-1.elb.amazonaws.com/